<!DOCTYPE html>
<html>
<head>
	<title>BubbleTeaStore Register</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
	<div class="header" style="text-align: center;">
		<h1>If you don't have an account, please register here!</h1>
	</div>

	<form method="post" action="signup.php">
		<table style="text-align: center;">
			<tr>
				<td>Email</td>
				<td><input type="text" name="Email" class="textInput"></td>
			</tr>
			<tr>
				<td>Firstname</td>
				<td><input type="text" name="Firstname" class="textInput"></td>
			</tr>
			<tr>
				<td>Lastname</td>
				<td><input type="text" name="Lastname" class="textInput"></td>
			</tr>
			<tr>
				<td>Password:</td>
				<td><input type="password" name="Password" class="textInput"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" name="Signup" value="Signup"></td>
			</tr>
			 <p>
     		 	Have an account? <a href="login.php">Sign in</a>
   			 </p>
		</table>
	</form>
</body>
</html>>