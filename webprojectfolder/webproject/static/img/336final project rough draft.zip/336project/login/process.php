<?php
	// get values from form in the login page
	$Email= $_POST['email'];
	$Password= $_POST['pass'];

	// injection 
	$Email=stripcslashes($Email);
	$Password=stripcslashes($Password);
	$Email=mysql_real_escape_string($Email);
	$Password=mysql_real_escape_string($Password);


	// connect to the server and select databse
	mysql_connect("localhost", "root", "");
	mysql_select_db("bubbletea");

	//Query the databse for user
	// change the user 
	$sql=mysql_query("SELECT * from membership where Email='$Email' and Password='$Password'") or die("not able to find such a membership".mysql_error());


	$row=mysql_fetch_array($sql);


	if ($row['Email']==$Email &&$row['Password']==$Password){
		echo"Login successfully!!! What do you want to do next?" .$row['Email'];
		header('location: ../home.php');
	} else {
	if (empty($Email)){
		echo "Email is required";
	}
	else if (empty($Password)){
		echo "Password is required";
	} else {
		echo "Can't find you,I am so sorry!";
	}
	}
	
?>