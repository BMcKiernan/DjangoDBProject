<?php
	session_start();

	//connect to database
	$db=mysqli_connect("localhost", "root", "","bubbletea");
	if (isset($_POST['Signup'])) {
		//session_start();
		$Email=mysql_real_escape_string($_POST['Email']);
		$Firstname=mysql_real_escape_string($_POST['Firstname']);
		$Lastname=mysql_real_escape_string($_POST['Lastname']);
		$Password=mysql_real_escape_string($_POST['Password']);
		if (empty($Email)||empty($Firstname)||empty($Lastname)||empty($Password)) {
			echo "please finish the information";
		} else {
			//$Password=md5($Password);
			$sql="INSERT INTO membership(Email, Firstname, Lastname, Password) VALUES ('$Email','$Firstname','$Lastname','$Password')";
			mysqli_query($db, $sql);
			$_SESSION['Email']=$Email;
			$_SESSION['success']= "You have signed up sucessfully, congradulations!";
			header('location: ../home.php');
		}
		
	} 
	
?>