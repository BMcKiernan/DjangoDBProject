<!DOCTYPE html>
<html>
<head>
	<title>BubbleTeaStore Login</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div id="form">
		<form action="process.php" method="POST">
		<p>
			<label>Email:</label>
			<input type="text" id="email" name="email"/>
		</p>
		<p>
			<label>Password:</label>
			<input type="password" id="pass" name="pass"/>
		</p>
		<p>
			<input type="submit" id="bottom" name="Login"/>
		</p>
		<p>
     		Don't have an account? <a href="register.php">Sign up</a>
   		</p>
		</form>
	</div>

</body>
</html>