<?php
	// get the price from the user
	
	session_start();
    $Price= $_POST['price'];
	$Price=stripcslashes($Price);
	$Price=mysql_real_escape_string($Price);
	// connect to databse
	$connect= mysqli_connect("localhost", "root", "", "bubbletea");
	if (isset($_POST['Search'])) {
		//session_start();
		if (empty($Price)) {
			echo "please enter the price range which you want!";
		} else if($Price<=0){
			echo "The number which you entered is not available, please go back and enter another one!";
		}else {
			$sql="SELECT * from Product where Price<='$Price';";
			$result=mysqli_query($connect, $sql) or die(mysqli_error($connect));
			$check=mysqli_num_rows($result);

			if($check<1){
				echo "there no production in such a price range, please go back and enter another one!";
			}else {
				while($row =mysqli_fetch_assoc($result)){
					echo "Product_number is ", $row['Product_number'],"; ","Price is ", $row['Price'], "; ", "Material is ", $row['Material'], "; ". "<br>";
				}
			}
			
		}
		
	} 






?>