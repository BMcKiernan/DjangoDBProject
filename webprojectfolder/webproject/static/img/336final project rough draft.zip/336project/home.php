<!DOCTYPE html>
<html>
<head>
	<title>BubbleTea-homepage</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body id="homepage">	
	<div class="home" style="text-align: center; color: #1946e8; padding: 0px; margin: 0px; "> 
	<h1>Home Page</h1>
	<h2>Yes! You are successfully logined in there!</h2>
	<h3>Let's do something exciting!</h3>
	<h3>Get the information which you would like to know!</h3>
	</div>

	<div id="query1" style="text-align: center;color: #3d2372; padding-top: 25px; margin: 3px auto; border: 1px solid, black">
		<form action="query1.php" method="POST">
		<p>
			<label>If you are insterested, we can find productions for you:</label>
			<!--in this qurey, the users are going to input the pirce range and then we are going to find the producions in that price range!-->
		</p>
		<p>
			<label>Price range (below): </label>
			<input type="text" id="price" name="price"/>
		</p>
		<p>
			<input type="submit" id="bottom" name="Search"/>
		</p>
		</form>
	</div>

	<div id="query2" style="text-align: center; color: #4d24a0; padding-top: 25px; margin: 3px auto; border: 1px solid, black">
		<form action="query2.php" method="POST">
		<p>
			<label>If you are insterested, we can give you personal perchase history:</label>
			<!--in this qurey, the users are going to input any user's email and then we are going to show them their perchase history. Within a perticular time-->
		</p>
		<p>
			<label>The user which you are searching for (type the email address): </label>
			<input type="text" id="email" name="Email"/>
		</p>
		<p>
			<input type="submit" id="find" name="Find"/>
		</p>
		</form>
	</div>

	<div id="query3" style="text-align: center; color: #582faa; padding-top: 25px; margin: 3px auto; border: 1px solid, black">
		<form action="query3.php" method="POST">
		<p>
			<label>If you are insterested, we can give you information of Store branches around you!</label>
			<!--in this qurey, the users are going to input any user's location and then we are going to give them the information of store branches srounding them-->
		</p>
		<p>
			<label>Tell me the city which you are located:</label>
			<input type="text" id="city" name="city"/>
		</p>
		<p>
			<input type="submit" id="go" name="Go"/>
		</p>
		</form>
	</div>

		<div id="query4" style="text-align: center; color: #582faa; padding-top: 25px; margin: 3px auto; border: 1px solid, black">
		<form action="query4.php" method="POST">
		<p>
			<label>If you are insterested, we can give you the rank of pruchase of each branches!</label>
			<!--in this qurey, the users are going to input the address of a branches, then we are going to provide the selling rank of this store-->
		</p>
		<p>
			<label>Tell me which branches you want to loot at (type the address):</label>
			<input type="text" id="add" name="add"/>
		</p>
		<p>
			<input type="submit" id="explore" name="explore"/>
		</p>
		</form>
	</div>


</body>
</html>