<?php
	// get the Email from the user
	
	session_start();
    $City= $_POST['city'];
	$City=stripcslashes($City);
	$City=mysql_real_escape_string($City);
	// connect to databse
	$connect= mysqli_connect("localhost", "root", "", "bubbletea");
	if (isset($_POST['Go'])) {
		//session_start();
		if (empty($City)) {
			echo "If you want to get the information of store branches, please enter the city which you are located!";
		} else {
			// this is very important to write a new and proper SQL

			$sql="SELECT Address, City, material FROM Branches B, Sales S, Product P WHERE B.Address=S.Branchadd and  S.Product_number= P.Product_number and B.City='$City' ORDER BY Address;";
			$result=mysqli_query($connect, $sql) or die(mysqli_error($connect));
			$check=mysqli_num_rows($result);

			if($check<1){
				echo "There is store branches surround you!";
			}else {
				//echo $check;
				while($row =mysqli_fetch_assoc($result)){
					echo "The address of branches is ", $row['Address'],"; ","in the City: ", $row['City'],"; ","providing: ", $row['material'],"; " . "<br>";
				}
			}
			
		}
		
	} 


?>