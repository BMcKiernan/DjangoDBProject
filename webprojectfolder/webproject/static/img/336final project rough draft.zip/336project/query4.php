<?php
	// get the Email from the user
	
	session_start();
    $add= $_POST['add'];
	$add=stripcslashes($add);
	$add=mysql_real_escape_string($add);
	// connect to databse
	$connect= mysqli_connect("localhost", "root", "", "bubbletea");
	if (isset($_POST['explore'])) {
		//session_start();
		if (empty($add)) {
			echo "If you want to the selling rank of this branches, please enter its address!";
		} else {
			// this is very important to write a new and proper SQL
			$sql="SELECT material, SUM(Quantity) as Quantity, Address FROM Purchase_history PH, product P WHERE PH.Address='wtf road' and PH.Product_number=P.Product_number GROUP BY PH.Product_number ORDER BY Quantity DESC;";
			$result=mysqli_query($connect, $sql) or die(mysqli_error($connect));
			$check=mysqli_num_rows($result);

			if($check<1){
				echo "There is no record sorry!";
			}else {
				//echo $check;
				while($row =mysqli_fetch_assoc($result)){
					echo "The address of branches is ", $row['Address'],"; ","production is: ", $row['material'],"; ", "Quantity of selling is: ", $row['Quantity'] . "<br>";
				}
			}
			
		}
		
	} 


?>