<?php
	// get the Email from the user
	
	session_start();
    $Email= $_POST['Email'];
	$Email=stripcslashes($Email);
	$Email=mysql_real_escape_string($Email);
	// connect to databse
	$connect= mysqli_connect("localhost", "root", "", "bubbletea");
	if (isset($_POST['Find'])) {
		//session_start();
		if (empty($Email)) {
			echo "please enter user's email which you are searching for!";
		} else {
			// this is very important to write a proper SQL

			$sql="SELECT SUM(Quantity) as Quantity, Firstname, Lastname, material from Product P, Purchase_history PH, Membership M where P.Product_number=PH.Product_number and M.Email=PH.Email and PH.Email='$Email' GROUP BY PH.Product_number ORDER BY PH.Quantity;";
			$result=mysqli_query($connect, $sql) or die(mysqli_error($connect));
			$check=mysqli_num_rows($result);

			if($check<1){
				echo "there is no record of his/her perchase!";
			}else {
				//echo $check;
				echo "The user is;                    ", "Quantity is;               ", "The Product is;             " . "<br>";
				while($row =mysqli_fetch_assoc($result)){
					echo $row['Firstname']," ", $row['Lastname'], ";                   ", $row['Quantity'], ";             ", $row['material'] . "<br>";
				}
			}
			
		}
		
	} 


?>